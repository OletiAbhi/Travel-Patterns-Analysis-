"""
app.py  –  Flask backend for Uber Trips Analysis Dashboard
Run:  python app.py
"""

import os, json, sys
import numpy as np
import pandas as pd
import joblib
from sklearn.preprocessing import StandardScaler

from flask import Flask, render_template, jsonify, request

app = Flask(__name__)


# ── Preprocessing Functions ───────────────────────────────────────────────────
def load_and_clean(filepath):
    """Load CSV and perform basic cleaning."""
    df = pd.read_csv(filepath)
    df['pickup_time'] = pd.to_datetime(df['pickup_time'])
    df['drop_time']   = pd.to_datetime(df['drop_time'])
    df.dropna(subset=['pickup_lat', 'pickup_lng', 'drop_lat', 'drop_lng'], inplace=True)
    df = df[df['status'].str.lower() == 'completed'].copy()
    return df


def engineer_features(df):
    """Extract time-based and derived features for clustering."""
    df = df.copy()
    df['hour']           = df['pickup_time'].dt.hour
    df['day_of_week']    = df['pickup_time'].dt.dayofweek   # 0=Monday
    df['month']          = df['pickup_time'].dt.month
    df['is_weekend']     = (df['day_of_week'] >= 5).astype(int)
    df['trip_duration']  = (df['drop_time'] - df['pickup_time']).dt.total_seconds() / 60
    df['speed_kmph']     = df['distance_km'] / (df['trip_duration'] / 60).replace(0, np.nan)
    df['fare_per_km']    = df['fare_amount'] / df['distance_km'].replace(0, np.nan)
    
    # Time-of-day category
    df['time_category'] = pd.cut(df['hour'],
                                 bins=[-1, 5, 11, 16, 20, 23],
                                 labels=['Night', 'Morning', 'Afternoon', 'Evening', 'Late Night'])
    return df

# ── Paths ─────────────────────────────────────────────────────────────────────
BASE_DIR   = os.path.dirname(__file__)
DATA_DIR   = os.path.join(BASE_DIR, 'data')
MODELS_DIR = os.path.join(BASE_DIR, 'models')
CSV_PATH   = os.path.join(DATA_DIR, 'uber_trips.csv')

# ── Lazy load models & data ───────────────────────────────────────────────────
_cache = {}


def _load_all():
    if _cache:
        return _cache

    # Data
    if os.path.exists(os.path.join(MODELS_DIR, 'processed_trips.csv')):
        df = pd.read_csv(os.path.join(MODELS_DIR, 'processed_trips.csv'))
    elif os.path.exists(CSV_PATH):
        df = load_and_clean(CSV_PATH)
        df = engineer_features(df)
    else:
        raise FileNotFoundError(f'Please run the notebook first to generate models and data. Expected: {CSV_PATH}')

    _cache['df'] = df

    # Models
    for name, path in [
        ('kmeans',    os.path.join(MODELS_DIR, 'kmeans_model.pkl')),
        ('scaler_km', os.path.join(MODELS_DIR, 'scaler_kmeans.pkl')),
        ('dbscan',    os.path.join(MODELS_DIR, 'dbscan_model.pkl')),
        ('scaler_db', os.path.join(MODELS_DIR, 'scaler_dbscan.pkl')),
    ]:
        _cache[name] = joblib.load(path) if os.path.exists(path) else None

    # Summary
    summary_path = os.path.join(MODELS_DIR, 'summary.json')
    _cache['summary'] = json.load(open(summary_path)) if os.path.exists(summary_path) else {}

    return _cache


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/api/summary')
def api_summary():
    c = _load_all()
    df = c['df']
    summary = c.get('summary', {})

    # Build live stats if summary is empty
    if not summary:
        summary = {
            'total_trips':    int(len(df)),
            'cities':         df['city'].unique().tolist() if 'city' in df else [],
            'avg_fare':       float(df['fare_amount'].mean().round(2)) if 'fare_amount' in df else 0,
            'avg_distance':   float(df['distance_km'].mean().round(2)) if 'distance_km' in df else 0,
            'kmeans_k':       int(df['kmeans_cluster'].nunique()) if 'kmeans_cluster' in df else 0,
            'dbscan_clusters': 0,
            'dbscan_outliers': 0,
        }

    return jsonify(summary)


@app.route('/api/trips_by_hour')
def trips_by_hour():
    df = _load_all()['df']
    city = request.args.get('city', 'all')
    if city != 'all' and 'city' in df.columns:
        df = df[df['city'] == city]
    data = df['hour'].value_counts().sort_index()
    return jsonify({'hours': data.index.tolist(), 'counts': data.values.tolist()})


@app.route('/api/trips_by_day')
def trips_by_day():
    df = _load_all()['df']
    city = request.args.get('city', 'all')
    if city != 'all' and 'city' in df.columns:
        df = df[df['city'] == city]
    labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    data   = df['day_of_week'].value_counts().sort_index()
    return jsonify({'days': labels, 'counts': [int(data.get(i, 0)) for i in range(7)]})


@app.route('/api/fare_distance')
def fare_distance():
    df = _load_all()['df']
    sample = df[['distance_km', 'fare_amount', 'kmeans_cluster']].dropna().sample(min(800, len(df)))
    return jsonify({
        'distance': sample['distance_km'].round(2).tolist(),
        'fare':     sample['fare_amount'].round(2).tolist(),
        'cluster':  sample['kmeans_cluster'].astype(int).tolist(),
    })


@app.route('/api/cluster_profiles')
def cluster_profiles():
    c  = _load_all()
    df = c['df']
    if 'kmeans_cluster' not in df.columns:
        return jsonify({})
    cols = ['distance_km', 'fare_amount', 'hour', 'trip_duration', 'speed_kmph', 'fare_per_km']
    cols = [col for col in cols if col in df.columns]
    profiles = df[df['kmeans_cluster'] >= 0].groupby('kmeans_cluster')[cols].mean().round(2)
    return jsonify(profiles.to_dict(orient='index'))


@app.route('/api/geo_data')
def geo_data():
    df = _load_all()['df']
    cluster_type = request.args.get('type', 'kmeans')
    cluster_col  = 'kmeans_cluster' if cluster_type == 'kmeans' else 'dbscan_cluster'
    cols = ['pickup_lat', 'pickup_lng', cluster_col]
    cols = [c for c in cols if c in df.columns]
    sample = df[cols].dropna().sample(min(1000, len(df)))
    sample = sample.rename(columns={cluster_col: 'cluster'})
    return jsonify(sample.to_dict(orient='records'))


@app.route('/api/payment_distribution')
def payment_distribution():
    df = _load_all()['df']
    if 'payment_method' not in df.columns:
        return jsonify({})
    data = df['payment_method'].value_counts()
    return jsonify({'labels': data.index.tolist(), 'values': data.values.tolist()})


@app.route('/api/cities')
def cities():
    df = _load_all()['df']
    if 'city' in df.columns:
        return jsonify(['all'] + df['city'].unique().tolist())
    return jsonify(['all'])


@app.route('/api/city_coordinates')
def city_coordinates():
    """Return list of cities with their default coordinates."""
    df = _load_all()['df']
    
    if 'city' not in df.columns:
        return jsonify({'cities': []})
    
    # Get unique cities with their mean coordinates
    city_coords = df.groupby('city').agg({
        'pickup_lat': 'mean',
        'pickup_lng': 'mean'
    }).round(4).reset_index()
    
    cities = []
    for _, row in city_coords.iterrows():
        cities.append({
            'name': row['city'],
            'lat': float(row['pickup_lat']),
            'lng': float(row['pickup_lng'])
        })
    
    cities.sort(key=lambda x: x['name'])
    return jsonify({'cities': cities})


@app.route('/api/suggestions')
def suggestions():
    """Return distance and fare suggestions based on dataset percentiles."""
    df = _load_all()['df']
    
    # Calculate percentiles for suggestions
    distance_percentiles = df['distance_km'].quantile([0.25, 0.50, 0.75]).round(1).tolist()
    fare_percentiles = df['fare_amount'].quantile([0.25, 0.50, 0.75]).round(2).tolist()
    
    # Also include min/max for context
    distance_stats = {
        'min': float(df['distance_km'].min().round(1)),
        'max': float(df['distance_km'].max().round(1)),
        'suggestions': distance_percentiles
    }
    
    fare_stats = {
        'min': float(df['fare_amount'].min().round(2)),
        'max': float(df['fare_amount'].max().round(2)),
        'suggestions': fare_percentiles
    }
    
    return jsonify({
        'distance': distance_stats,
        'fare': fare_stats
    })


@app.route('/api/predict_cluster', methods=['POST'])
def predict_cluster():
    """Predict K-Means cluster for a new trip."""
    c        = _load_all()
    kmeans   = c.get('kmeans')
    scaler   = c.get('scaler_km')

    if kmeans is None or scaler is None:
        return jsonify({'error': 'Model not trained yet. Run the notebook first.'}), 503

    body = request.get_json(force=True)
    try:
        features = np.array([[
            float(body.get('pickup_lat', 40.7)),
            float(body.get('pickup_lng', -74.0)),
            int(body.get('hour', 12)),
            int(body.get('day_of_week', 0)),
            float(body.get('distance_km', 5)),
            float(body.get('fare_amount', 15)),
            int(body.get('is_weekend', 0)),
        ]])
        scaled  = scaler.transform(features)
        cluster = int(kmeans.predict(scaled)[0])
        return jsonify({'predicted_cluster': cluster})
    except Exception as e:
        return jsonify({'error': str(e)}), 400


# ── Main ──────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    os.makedirs(DATA_DIR,   exist_ok=True)
    os.makedirs(MODELS_DIR, exist_ok=True)
    print('🚗 Uber Trips Analysis — starting Flask server...')
    print('   Open http://127.0.0.1:5000 in your browser')
    app.run(debug=True, host='0.0.0.0', port=5000)
